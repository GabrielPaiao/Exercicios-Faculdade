Código por: Gabriel Pereira Paião, ADS, Banco de Dados

Como solicitado:
Considere as relações abaixo:
[ x ] Pessoa (id_pessoa, nome, id_cidade)
[ x ] Cidade (id_cidade, nome, estado)
[ x ] Defina também as relações Telefone e Email. Com base nisso, crie um código python que implemente essas relações e define uma função que retorne uma pessoa por linha com todos os seus dados associados.

[ x ] Considere os conceitos de dict, list e def para elaborar sua solução.

! IMPORTANTE: Não utilize LLM para auxiliar com esse código. O exercício é focado no desenvolvimento da sua capacidade lógica e construtiva para elaborar a solução.