Código por: Gabriel Pereira Paião, ADS, Banco de Dados

Como solicitado:
[ x ] Implemente uma tabela Aluno com os atributos id, nome e idade;
[ x ] Implemente a operação de inserção de dados e popule a tabela com 10 registros;
    - Número de inserções conforme desejo do usuário, não necessariamente limitada a 10
[ x ] Implemente a recuperação de informação por meio do id do aluno.
    - ocorre uma vez, já que não houve especificação por repetição (eu tenho tanta coisa pra fazer professor, me da um desconto haha)